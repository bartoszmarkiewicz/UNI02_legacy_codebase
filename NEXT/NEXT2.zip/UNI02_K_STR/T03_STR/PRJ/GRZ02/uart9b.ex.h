void InitDtaUART1(void);
void inline IntUSARTTR(void);
void inline IntUSARTRC(void);
