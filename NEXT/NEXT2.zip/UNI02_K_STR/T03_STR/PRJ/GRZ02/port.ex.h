void InitDtaPort(void);
void inline StabPort(void);
bit RdPrt(const unsigned char Index);
void SetPrt(const unsigned char Index, const unsigned char nw);
void RefPrt(const unsigned char Index);
inline bool InRdPrt(const unsigned char Index);

