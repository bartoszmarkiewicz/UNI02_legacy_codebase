#include "czcw.h"				//parametry lokalne

void InitCzCw(void);
void SetParPrzCw(void);
void IntCzCw(void);
void PomiarPrzCW(void);
