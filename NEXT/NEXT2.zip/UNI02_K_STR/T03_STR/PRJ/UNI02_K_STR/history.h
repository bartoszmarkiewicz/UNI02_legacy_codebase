/*history.h*/
//----------------------------------------------------------
#ifndef	_HISTORY_H
#define	_HISTORY_H
#include "history.tp.h"

#define _HISTSZ 16
#define _ESTBL 4        //liczba zapamietywanych statusow wylaczenia z blokada awaryjna
#define _ESTPZ 23       //liczba pozycji statusu wylaczenia awaryjnego z blokada

//----------------------------------------------------------
#endif		/*_HISTORY_H*/

					
