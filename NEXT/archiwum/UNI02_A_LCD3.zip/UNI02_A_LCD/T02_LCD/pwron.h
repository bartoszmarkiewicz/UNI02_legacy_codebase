/*pwron.h*/
#ifndef	_PWRON_H
#define	_PWRON_H

#define _TPWRON 15			//[ds] czas zwloki na wygaszenie stanow nieustalonych po zal. zasilania

//rtimer.c
extern void StartRTdS(const unsigned char Index);
extern unsigned char RTdS(const unsigned char Index);

#endif /*_PWRON_H*/
