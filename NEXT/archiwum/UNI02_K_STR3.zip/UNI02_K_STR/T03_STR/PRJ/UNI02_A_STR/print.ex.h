#include "print.h"				//parametry lokalne

void PrintErr(const unsigned char kod, const unsigned char pls);
void PrintErrCs(const unsigned char kod,const unsigned char cs, const unsigned char pls);
void EndErr(void);
void PrintL3(void);
void EndL3(void);
