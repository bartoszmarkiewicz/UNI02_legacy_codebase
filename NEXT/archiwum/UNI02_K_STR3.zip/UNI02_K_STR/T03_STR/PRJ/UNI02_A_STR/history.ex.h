#include "history.tp.h"

unsigned char RefBHist(const unsigned char res);
void ToWriteESTAT(void);
void RefBStat(const unsigned char res);
void ClrHFLG(void);
