/*pwron.h*/
#ifndef	_PWRON_H
#define	_PWRON_H

#define _TPWRON 15			//[ds] czas zwloki na wygaszenie stanow nieustalonych po zal. zasilania

#endif /*_PWRON_H*/
