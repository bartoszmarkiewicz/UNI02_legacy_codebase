#include "smgs_rs9b.tp.h"		//typy danych

inline void IncRSTimer(void);
inline void IncRSTimer2(void);

void InitReceptProc(void);
void ReceptDataLCD(void);