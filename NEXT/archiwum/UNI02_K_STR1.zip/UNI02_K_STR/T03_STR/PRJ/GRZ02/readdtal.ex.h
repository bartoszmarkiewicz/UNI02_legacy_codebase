unsigned char ReadData(unsigned char k,unsigned char *dt,unsigned char min,unsigned char max,const unsigned char step,unsigned char wrn);
unsigned char ReadDataX(unsigned char k,unsigned char *dt,unsigned char min,unsigned char max,const unsigned char step,const unsigned char step2,unsigned char wrn);
unsigned char ReadDataONL(unsigned char k,unsigned char *dt,unsigned char min,unsigned char max,const unsigned char step,unsigned char wrn);
unsigned char ReadDataXONL(unsigned char k,unsigned char *dt,unsigned char min,unsigned char max,const unsigned char step,const unsigned char step2,unsigned char wrn);
unsigned char ReadDataXONLI(unsigned char k,unsigned char *dt,unsigned char max,const unsigned char step,const unsigned char step2);
unsigned char ReadDataXONLD(unsigned char k,unsigned char *dt,unsigned char min,const unsigned char step,const unsigned char step2);

