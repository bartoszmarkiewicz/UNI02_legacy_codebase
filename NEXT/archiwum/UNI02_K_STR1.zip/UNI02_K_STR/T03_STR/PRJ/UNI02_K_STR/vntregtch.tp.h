/*vntregtch.tp.h*/
//typy danych dla pliku vntregtpch.c
//----------------------------------------------------------
#ifndef	_VNTREGTCH_TPH
#define	_VNTREGTCH_TPH
//----------------------------------------------------------
	typedef struct	{
				unsigned char dvnt;
				unsigned char dpwm;
			}KALVnt;
            typedef struct	{
				unsigned int dvnt;
				unsigned int dpwm;
			}KALVnt2;
//----------------------------------------------------------
#endif /*_VNTREGTCH_TPH*/