#include "rgl.tp.h"

void Moduluj(void);
void RestartMod(void);

bit Trosnie(const unsigned char t);
bit Tmaleje(const unsigned char t);
bit Tstoi(void);
bit Tnizsza(const unsigned char t);
bit Twyzsza(const unsigned char t);
bit Trowna(void);
bit TFrosnie(const unsigned char t);
bit TFmaleje(const unsigned char t);
bit TFstoi(void);


