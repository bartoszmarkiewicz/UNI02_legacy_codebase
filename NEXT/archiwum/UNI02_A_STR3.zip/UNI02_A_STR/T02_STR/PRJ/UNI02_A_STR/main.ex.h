#include "main.tp.h"

void main_prc(void);
void ErrPTG(void);
void SetLowPMP(void);
