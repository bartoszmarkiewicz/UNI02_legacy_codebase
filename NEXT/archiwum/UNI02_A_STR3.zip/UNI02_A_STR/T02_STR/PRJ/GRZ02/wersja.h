/*wersja.h*/
//----------------------------------------------------------
#define _WERSJA 3			//aktualna wersja produkcyjna oprogramowania (1=1.1, 2=1.2 ... 10=2.0)

/*
Wersja 3 - (16.03.2020)	
-przejscie na mikrokontroler Q,
-zmiana kompilatora na xc8
 
(06.07.2020)
-optymalizacja algorytm�w PWM 
-optymalizacja algorytm�w zwiazanych z przetwornikiem AC 
*/
//----------------------------------------------------------
