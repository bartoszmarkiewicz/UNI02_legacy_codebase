#include "pomiar.tp.h"				//parametry lokalne

void InitDataPmr(void);
void inline IncPmrTimer(void);
void GoldenEye(void);
void PomiarCW(void);
void PomiarPCW(void);
void WritePCW(void);
void FiltrPomiarowyCW(void);

