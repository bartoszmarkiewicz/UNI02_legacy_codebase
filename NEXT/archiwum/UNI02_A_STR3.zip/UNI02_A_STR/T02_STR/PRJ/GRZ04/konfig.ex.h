#include "konfig.tp.h"

void EnKonf(void);
void MKonfiguracja(void);
void RdEEParam(void);

unsigned char ReadEEPCW(void);
void WriteEEPCW(void);
