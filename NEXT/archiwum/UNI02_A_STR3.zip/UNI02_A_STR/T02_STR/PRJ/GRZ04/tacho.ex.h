void inline IntTacho(void);
void inline IntINT0(void);
void inline IncTimTacho(void);
void PomiarVNT(void);
void PredkoscZmianVNT(void);
