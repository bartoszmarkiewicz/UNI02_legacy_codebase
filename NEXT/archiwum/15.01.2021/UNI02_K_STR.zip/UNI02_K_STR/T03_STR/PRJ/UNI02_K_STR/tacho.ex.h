void inline IntTacho(void);
void inline IntINT0(void);
void inline IncTimTacho(void);
void ClrTachoDta(void);
void PomiarVNT(void);
void PredkoscZmianVNT(void);

void SetNstVNT(unsigned char doc);
void ClrDtV(void);

bit Vrosnie(const unsigned char t);
bit Vmaleje(const unsigned int t);
bit Vstoi(void);
bit Vnizsza(const unsigned int t);
bit Vwyzsza(const unsigned int t);
bit Vrowna(void);
bit VTrosnacy(const unsigned char t);
bit VTmalejacy(const unsigned char t);
bit VTzerowy(void);

