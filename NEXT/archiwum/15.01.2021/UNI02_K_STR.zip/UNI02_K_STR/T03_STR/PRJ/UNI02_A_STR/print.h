/*print.h*/
/*Sposob reprezentacji danych analogiczny jak w rodzinie ster. TSTR xxxx*/
#ifndef	_PRINT_H
#define	_PRINT_H

//--------------------------------------------------------------
//Kolejne argumenty proc PrintErr 
#define _E1		0x01
#define _E2		0x02
#define _E3		0x03
#define _E4		0x04
#define _E5		0x05
#define _E6		0x06
#define _E7		0x07
#define _E8		0x08
#define _E9		0x09
#define _E10	0x10
#define _E11	0x11
#define _E12	0x12

//--------------------------------------------------------------
#endif		/*_PRINT_H*/ 
