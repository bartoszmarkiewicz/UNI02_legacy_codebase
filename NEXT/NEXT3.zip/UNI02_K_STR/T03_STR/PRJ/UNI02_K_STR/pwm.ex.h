#include "pwm.tp.h"
#include "global.h"

void InitDtaPWM(void);
void inline IntPWM3(void);
void inline IntPWM2(void);

void ModParam(void);
void WritePWM3(const unsigned char tpwm);
void WritePWM2(const unsigned char tpwm);
void WritePWM3H(const unsigned int tpwm);





