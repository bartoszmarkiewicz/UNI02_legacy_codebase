#include "main.ex.h"
#include "ac.ex.h"
#include "eeprom.ex.h"
#include "i2c_s.ex.h"
#include "i2c_proc.ex.h"
#include "uart9b.ex.h"
#include "isr.ex.h"
#include "port.ex.h"
#include "rtimer.ex.h"
#include "smgs_rs9b.ex.h"
#include "konfig.ex.h"
#include "pomiar.ex.h"
#include "tacho.ex.h"
#include "vntregtch.ex.h"
#include "pompa.ex.h"
#include "pwm.ex.h"
#include "rgl.ex.h"
#include "history.ex.h"
#include "print.ex.h"
#include "pwron.ex.h"
#include "czcw.ex.h"






