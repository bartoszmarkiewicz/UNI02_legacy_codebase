#include "pomiar.tp.h"				//parametry lokalne

void InitDataPmr(void);
void inline IncPmrTimer(void);
void GoldenEye(void);
void PomiarCO(void);
void PomiarIN(void);
void PomiarCW(void);
void PomiarZW(void);
void PomiarPCO(void);
unsigned char GetPGD_PCO(void);
void PomiarPCW(void);
void PomiarECO(void);
void PomiarPFN(void);
void PomiarCS(void);
void SetModPCO(void);
void FiltrPomiarowyCOCW(void);
void SetTrbPGD(void);