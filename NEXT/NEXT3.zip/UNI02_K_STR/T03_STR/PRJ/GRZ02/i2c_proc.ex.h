void inline SetTData(void);
void inline FormatDataIMY(void);
void inline ToWork(void);
void inline SetRData(void);
