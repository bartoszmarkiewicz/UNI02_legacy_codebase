#include "defaultpar.h"

void inline WriteEEPROM(unsigned int adr,unsigned char data);
void if_WriteEEPROM(unsigned int adr, unsigned char dta);
unsigned char ReadEEPROM(unsigned int adr);
