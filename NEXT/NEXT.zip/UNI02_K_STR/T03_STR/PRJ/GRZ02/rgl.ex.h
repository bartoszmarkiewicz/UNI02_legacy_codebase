#include "rgl.tp.h"

void Moduluj(void);
void RestartMod(void);
unsigned char FirstPCW4(void);


