//UNI02Q
//IDENTYFIKATOR PROJEKTU
#define _TYP_PRJ 1		//rodzaj sterownika (1-sterownik do kotlow kondensacyjnych, 2-sterownik do kotlow atmosferycznych, 3-sterownik do pogrzewaczy GRZ02, 4-sterownik do podgrzewaczy GRZ04)
