#include "pompa.tp.h"		//typy danych

void RglPmp(void);
unsigned char ProcToPmpPwm(unsigned char prc);
void PmpToUP(void);
void PmpToDW(void);
