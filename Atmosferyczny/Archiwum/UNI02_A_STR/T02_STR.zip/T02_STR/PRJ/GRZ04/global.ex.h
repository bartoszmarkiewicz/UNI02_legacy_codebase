#include "main.ex.h"
#include "ac.ex.h"
#include "eeprom.ex.h"
#include "i2c_s.ex.h"
#include "i2c_proc.ex.h"
#include "uart9b.ex.h"
#include "isr.ex.h"
#include "port.ex.h"
#include "rtimer.ex.h"
#include "konfig.ex.h"
#include "wsw2.ex.h"
#include "print.ex.h"
#include "pomiar.ex.h"
#include "keypad.ex.h"
#include "readdtal.ex.h"
#include "pwm.ex.h"
#include "tacho.ex.h"
#include "pwron.ex.h"
#include "rgl.ex.h"






