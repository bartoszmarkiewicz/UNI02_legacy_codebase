#include "main.tp.h"

void main_prc(void);
void PomALL(void);
void ErrPTG(void);

