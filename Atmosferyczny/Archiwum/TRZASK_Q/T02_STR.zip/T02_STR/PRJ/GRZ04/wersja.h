/*wersja.h*/
//----------------------------------------------------------
#define _WERSJA 1			//aktualna wersja produkcyjna oprogramowania (1=1.1, 2=1.2 ... 10=2.0)

/*
Wersja 1 - opracowana 02.03.2024	
-przejscie na mikrokontroler Q,
-zmiana kompilatora na xc8

(06.07.2020)
-optymalizacja algorytm�w PWM
-optymalizacja algorytm�w pomiaru i zadawania predkosci obrotowej wentylatora 
-optymalizacja algorytm�w zwiazanych z przetwornikiem AC
*/
//----------------------------------------------------------
