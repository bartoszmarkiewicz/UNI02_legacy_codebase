#include "../../mcc_generated_files\adcc.h"

unsigned char ReadAC(adcc_channel_t chanel);
unsigned char ReadTabNTC(unsigned char zrAC);
unsigned char ReturnACfromNTC(unsigned char data);
signed char ReadTabZNTC(unsigned char zrAC);
unsigned int ReadAC16(adcc_channel_t chanel);
