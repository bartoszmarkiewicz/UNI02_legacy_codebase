#include "i2c_s.tp.h"

void InitDtaI2C(void);
void inline I2CSlaveTR(void);